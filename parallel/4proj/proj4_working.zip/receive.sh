#!/bin/bash

set -e

unzip package.zip
rm package.zip
