
int main(int argc, char* argv[])
{
    srand
    return 0;
}
